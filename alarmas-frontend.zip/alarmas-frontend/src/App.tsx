import { useCallback, useEffect, useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { AnimatePresence, motion } from 'motion/react'
import { CheckCircle2, Loader2 } from 'lucide-react'
import { api, errorMessage, USE_MOCK } from './lib/api'
import { aplicarConsulta } from './lib/consulta'
import type { Consulta, FiltroNivel } from './types'
import { TopBar } from './components/TopBar'
import { Sidebar } from './components/Sidebar'
import { Composer } from './components/Composer'
import { QueryForm } from './components/QueryForm'
import { AlarmTable } from './components/AlarmTable'
import { CreateAlarmModal } from './components/CreateAlarmModal'
import { ImportModal } from './components/ImportModal'
import { SummaryModal } from './components/SummaryModal'

type Panel = 'crear' | 'importar' | 'resumen' | null

function useNow(ms: number) {
  const [now, setNow] = useState(() => Date.now())
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), ms)
    return () => clearInterval(id)
  }, [ms])
  return now
}

export default function App() {
  const [filtro, setFiltro] = useState<FiltroNivel>('TODOS')
  const [consulta, setConsulta] = useState<Consulta>({})
  const [busqueda, setBusqueda] = useState('')
  const [panel, setPanel] = useState<Panel>(null)
  const [toast, setToast] = useState<string | null>(null)
  const now = useNow(30_000)

  const { data: todas = [], isLoading, isFetching, error, refetch } = useQuery({
    queryKey: ['alarmas'],
    queryFn: () => api.listarAlarmas(),
    refetchInterval: 60_000,
  })
  const data = useMemo(() => aplicarConsulta(todas, consulta), [todas, consulta])

  useEffect(() => {
    if (!toast) return
    const t = setTimeout(() => setToast(null), 3500)
    return () => clearTimeout(t)
  }, [toast])

  const cerrar = useCallback(() => setPanel(null), [])
  const abrir = (p: Panel) => () => setPanel(p)

  return (
    <>
      <TopBar busqueda={busqueda} onBusqueda={setBusqueda} fetching={isFetching} demo={USE_MOCK} onRefresh={() => refetch()} onCrear={abrir('crear')} onImportar={abrir('importar')} onResumen={abrir('resumen')} />

      <div className="mx-auto grid max-w-7xl gap-5 px-4 py-5 lg:grid-cols-[260px_minmax(0,1fr)]">
        <Sidebar data={data} value={filtro} onChange={setFiltro} onCrear={abrir('crear')} onImportar={abrir('importar')} onResumen={abrir('resumen')} />

        <main className="min-w-0 space-y-4">
          <Composer onCrear={abrir('crear')} onImportar={abrir('importar')} onResumen={abrir('resumen')} />
          <QueryForm onSearch={setConsulta} />
          {isLoading ? (
            <div className="grid h-48 place-items-center rounded-2xl border border-line bg-panel text-muted"><Loader2 className="animate-spin" /></div>
          ) : error ? (
            <div role="alert" className="rounded-2xl border border-crit/40 bg-crit/10 p-4 text-sm text-crit">No se pudieron cargar las alarmas: {errorMessage(error)}</div>
          ) : (
            <AlarmTable data={data} filtro={filtro} busqueda={busqueda} now={now} />
          )}
        </main>
      </div>

      <CreateAlarmModal open={panel === 'crear'} onClose={cerrar} onDone={setToast} />
      <ImportModal open={panel === 'importar'} onClose={cerrar} onDone={setToast} />
      <SummaryModal open={panel === 'resumen'} onClose={cerrar} />

      <AnimatePresence>
        {toast && (
          <motion.div role="status" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 12 }} className="fixed bottom-5 left-5 z-[60] flex items-center gap-2 rounded-xl border border-line bg-panel-2 px-4 py-3 text-sm shadow-xl">
            <CheckCircle2 size={18} className="text-ok" /> {toast}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
