import { BarChart3, BellRing, Plus, RefreshCw, Search, Upload, User } from 'lucide-react'

const circle = 'grid size-10 place-items-center rounded-full bg-panel-2 text-white transition hover:bg-line'

interface Props {
  busqueda: string
  onBusqueda: (v: string) => void
  fetching: boolean
  demo: boolean
  onRefresh: () => void
  onCrear: () => void
  onImportar: () => void
  onResumen: () => void
}

export function TopBar({ busqueda, onBusqueda, fetching, demo, onRefresh, onCrear, onImportar, onResumen }: Props) {
  return (
    <header className="sticky top-0 z-40 border-b border-line bg-panel/90 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-2.5">
        <div className="flex items-center gap-2.5">
          <div className="grid size-10 place-items-center rounded-full bg-gradient-to-br from-brand to-accent text-ink"><BellRing size={20} aria-hidden /></div>
          <div className="hidden leading-tight sm:block">
            <p className="font-semibold">Monitor de Alarmas</p>
            <p className="text-[11px] text-muted">{demo ? 'Modo demo' : 'API conectada'}</p>
          </div>
        </div>

        <label className="relative ml-1 max-w-sm flex-1">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" aria-hidden />
          <input value={busqueda} onChange={(e) => onBusqueda(e.target.value)} placeholder="Buscar en los resultados…" aria-label="Buscar en los resultados"
            className="w-full rounded-full bg-panel-2 py-2.5 pl-10 pr-4 text-sm placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-brand/60" />
        </label>

        <div className="ml-auto flex items-center gap-2">
          <button onClick={onCrear} aria-label="Crear alarma" title="Crear alarma" className={circle}><Plus size={19} /></button>
          <button onClick={onImportar} aria-label="Importar CSV" title="Importar CSV" className={circle}><Upload size={18} /></button>
          <button onClick={onResumen} aria-label="Resumen del día" title="Resumen del día" className={circle}><BarChart3 size={18} /></button>
          <button onClick={onRefresh} aria-label="Actualizar" title="Actualizar" className={circle}><RefreshCw size={17} className={fetching ? 'animate-spin' : ''} /></button>
          <div className="ml-1 hidden size-10 place-items-center rounded-full bg-brand/25 text-brand sm:grid" aria-hidden><User size={19} /></div>
        </div>
      </div>
    </header>
  )
}
